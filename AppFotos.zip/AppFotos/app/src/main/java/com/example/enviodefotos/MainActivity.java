package com.example.enviodefotos;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private Button _btnCamara, _btnWhatsapp, _btnCorreo;
    private ImageView _img;
    private Bitmap imgBitmap;

    private static final int REQUEST_CODIGO_CAMARA=200;

    private static final int REQUEST_CODIGO_CAPTURAR_IMAGEN=300;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _btnCamara = (Button) findViewById(R.id.btnCamara);
        _btnWhatsapp = (Button) findViewById(R.id.btnWhatsapp);
        _btnCorreo = (Button) findViewById(R.id.btnCorreo);
        _img = (ImageView) findViewById(R.id.imgFoto);

        _btnCamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirCamara();
            }
        });

        _btnWhatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnviarFotoWhatsapp();
            }
        });

        _btnCorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnviarFotoCorreo();
            }
        });
    }

    private void EnviarFotoWhatsapp() {
        if (imgBitmap != null) {

            String path = MediaStore.Images.Media.insertImage(getContentResolver(), imgBitmap, "Image Description", null);

            Intent intentW = new Intent();
            intentW.setAction(Intent.ACTION_SEND);
            intentW.putExtra(Intent.EXTRA_STREAM, Uri.parse(path));
            intentW.setType("image/*");
            intentW.setPackage("com.whatsapp");
            startActivity(intentW);
        } else {
            Toast.makeText(this, "Por favor, captura una imagen primero", Toast.LENGTH_SHORT).show();
        }
    }

    private void EnviarFotoCorreo() {

        if (imgBitmap != null) {

            String path = MediaStore.Images.Media.insertImage(getContentResolver(), imgBitmap, "Image Description", null);

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(path));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"irvingmachado08@gmail.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Gestion de Fotos");
            intent.putExtra(Intent.EXTRA_TEXT, "Cuerpo del correo");

            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(intent, "Enviar correo electrónico"));
            } else {
                Toast.makeText(this, "No se encontró una aplicación de correo electrónico", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Por favor, captura una imagen primero", Toast.LENGTH_SHORT).show();
        }
    }

    private void abrirCamara(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
         if(intent.resolveActivity(getPackageManager()) != null){
            startActivityForResult(intent, 1);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == RESULT_OK){
            Bundle extras = data.getExtras();
            imgBitmap = (Bitmap) extras.get("data");
            _img.setImageBitmap(imgBitmap);
        }
    }
}